﻿using MaterialDesignThemes.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp18.Core;
using MenuItem = WpfApp18.Core.MenuItem;

namespace WpfApp18
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            List<MenuItem> menu = new List<MenuItem>();

            menu.Add(new MenuItem("Ресурсы", PackIconKind.Image, new ItemCount(Brushes.Orange, 1232)));
            menu.Add(new MenuItem("Фильмы", PackIconKind.Cinema, new ItemCount(Brushes.DarkBlue, 95)));
            menu.Add(new MenuItem("Заметки", PackIconKind.Notes, new ItemCount(Brushes.DarkGreen, 1117)));
            menu.Add(new MenuItem("Документы", PackIconKind.Folder, new ItemCount(Brushes.DarkOrange, 191)));
            menu.Add(new MenuItem("Статьи", PackIconKind.Artist, new ItemCount(Brushes.Orange, 123)));
            menu.Add(new MenuItem("Новости", PackIconKind.Newspaper, new ItemCount(Brushes.DarkBlue, 95)));
            menu.Add(new MenuItem("Блог", PackIconKind.Blog, new ItemCount(Brushes.DarkGreen, 12)));
            menu.Add(new MenuItem("Рекстораны", PackIconKind.Food, new ItemCount(Brushes.DarkOrange, 5)));
            menu.Add(new MenuItem("Документы", PackIconKind.Folder, new ItemCount(Brushes.DarkOrange, 191)));
            menu.Add(new MenuItem("Статьи", PackIconKind.Artist, new ItemCount(Brushes.Orange, 123)));
            menu.Add(new MenuItem("Новости", PackIconKind.Newspaper, new ItemCount(Brushes.DarkBlue, 95)));
            menu.Add(new MenuItem("Блог", PackIconKind.Blog, new ItemCount(Brushes.DarkGreen, 12)));
            menu.Add(new MenuItem("Рестораны", PackIconKind.Food, new ItemCount(Brushes.DarkOrange, 5)));

            ListViewMenu.ItemsSource = menu;

        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void Grid_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }
    }
}
